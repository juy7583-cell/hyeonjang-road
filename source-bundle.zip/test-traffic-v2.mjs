import assert from 'node:assert/strict';
import {Tracker,Classifier,trafficMetrics} from './dist/engine.mjs';
const all=[[0,0],[1,0],[1,1],[0,1]],left=[[0,0],[.35,0],[.35,1],[0,1]];
const car=(x,y,stationary=true)=>({bbox:[x,y,.06,.09],class:'car',score:.9,stationary});
const stopped=[car(.08,.1),car(.08,.3),car(.08,.5),car(.2,.2)];
const moving=Array.from({length:8},(_,i)=>car(.4+i%4*.12,.1+Math.floor(i/4)*.3,false));
assert(trafficMetrics(stopped,all).score>=75,'queue of four stopped vehicles is congested even at low image occupancy');
assert(trafficMetrics([car(.1,.2)],all).score<35,'one isolated parked car is not a traffic jam');
assert(trafficMetrics(moving,all).score<35,'moving vehicles are free-flow in this sparse scene');
assert.equal(trafficMetrics([],all).score,null,'no detections must not imply free flow');
assert.equal(trafficMetrics(stopped,all,false).score,null,'warmup/dark frame must abstain');
const c=new Classifier();c.update([...stopped,...moving],0,{road:all,queue:left});
const r=c.update([...stopped,...moving],2,{road:all,queue:left});
assert(r.localTraffic.score>=75&&r.globalTraffic.score<65);
assert.equal(r.congestion,r.localTraffic.score);assert.equal(r.congestionScope,'국소 정체구역');
const t=new Tracker();let id;for(let s=0;s<=3;s+=.25){const ds=s===1.25?[]:[car(.1,.1)];const out=t.update(ds,s);if(s===0)id=out[0].id;if(s===1.25)assert.equal(out.length,0);if(s===3){assert.equal(out[0].id,id);assert(out[0].stationary);}}
console.log('PASS: localized closure, moving traffic, sparse parking, missing/dark abstention, short tracking gaps');
