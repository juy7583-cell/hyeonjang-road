import assert from 'node:assert/strict';import {TrafficEvidence,sameAppearance,applyEvidence} from './dist/traffic-evidence.mjs';
const road=[[0,0],[1,0],[1,1],[0,1]],w=200,h=200;
const pixels=new Uint8ClampedArray(w*h*4);for(let y=0;y<h;y++)for(let x=0;x<w;x++){const k=(y*w+x)*4,v=((x*7+y*11)%17)*13;pixels[k]=pixels[k+1]=pixels[k+2]=v;pixels[k+3]=255;}
const cars=[.2,.28,.36].map((x,i)=>({id:i+1,class:'car',bbox:[x,.4,.06,.1],confirmed:true,stationary:true,relativeSpeed:0}));
const config={road,width:w,height:h,pixels,light:120};let e=new TrafficEvidence(),r;for(let t=2;t<=4;t+=.25)r=e.update(cars,t,config);assert(r.evidenceScore>=65);
for(let t=4.25;t<=9;t+=.25)r=e.update([],t,config);assert.equal(r.retainedVehicles,3);assert(r.evidenceScore>=65,'visible stationary evidence retained');
r=e.update([],10,{...config,pixels:new Uint8ClampedArray(pixels.length)});assert.equal(r.retainedVehicles,0);r=e.update([],11,config);assert.equal(r.evidenceScore,null,'no detections not free flow');
e=new TrafficEvidence();for(let t=2;t<=5;t+=.25)r=e.update(cars.slice(0,2),t,config);assert(r.evidenceScore<65,'two parked cars cannot be congested');
e=new TrafficEvidence();for(let t=2;t<=4;t+=.25)r=e.update(cars,t,config);const moving=cars.map((d,i)=>({...d,bbox:[.6,.1+i*.2,.06,.1],stationary:false,relativeSpeed:1}));for(let t=4.25;t<=6.25;t+=.25)r=e.update(moving,t,{...config,pixels:new Uint8ClampedArray(pixels.length)});assert(r.evidenceScore<35,'positive clearance releases congestion');
assert(!sameAppearance(Array(400).fill(0),Array(400).fill(0)),'blank patches rejected');
e=new TrafficEvidence();for(let t=2;t<=4;t+=.25)r=e.update(cars,t,config);for(let t=4.25;t<=6;t+=.25)r=e.update(cars.slice(0,2),t,{...config,pixels:new Uint8ClampedArray(pixels.length)});assert(r.evidenceScore>=65,'same queue residual supports prior state');assert(r.evidenceState.includes('추정 유지'));
const result=applyEvidence({risk:0,autoReady:true,reasons:[]},r);assert.equal(result.safety,null);assert.equal(result.safetyObservation,'특정 징후 미검출');
console.log('PASS: visually supported missing tracks, evidence expiry, no-detection abstention, two-car parking cap, positive clearance, no safety 100');
