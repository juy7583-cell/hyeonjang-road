import assert from 'node:assert/strict';
import {InterferenceMonitor,mergeDetections} from './dist/engine.mjs';
const zone=[[.3,.3],[.7,.3],[.7,.7],[.3,.7]],truck={class:'truck',score:.9,bbox:[.4,.4,.2,.2]};
let m=new InterferenceMonitor();assert(!m.update([],0,zone).interference);assert(!m.update([truck],.25,zone).interference);assert(m.update([truck],.5,zone).interference);assert(!m.update([], .75,zone).interference);assert(!m.update([truck],1,zone).interference);assert(!m.update([truck],2,zone).interference);assert(!m.update([truck],2.25,zone,5).interference);assert(!m.update([truck],2.5,null).interference);assert(!m.update([{...truck,bbox:[.8,.8,.1,.1]}],2.75,zone).interference);
assert.equal(mergeDetections([truck,{...truck,class:'bus',score:.8}]).length,1);assert.equal(mergeDetections([truck,{...truck,class:'person'}]).length,2);assert.equal(mergeDetections([truck,{...truck,bbox:[.1,.1,.1,.1]}]).length,2);
console.log('PASS: two-frame confirmation, immediate release, gap/dark/no-zone abstention, outside-zone rejection, duplicate suppression without merging people/vehicles.');
