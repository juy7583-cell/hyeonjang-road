import assert from 'node:assert/strict';import {Tracker,Classifier,inside,validPolygon,occupancy} from './dist/engine.mjs';
const box=(x,y,w,h,c='car')=>({bbox:[x,y,w,h],class:c,score:.9});const all=[[0,0],[1,0],[1,1],[0,1]],gate=[[.3,.3],[.7,.3],[.7,.8],[.3,.8]],walk=[[.75,0],[1,0],[1,1],[.75,1]];const z={road:all,gate,walk};
assert(inside([.5,.5],gate));assert(!inside([.1,.1],gate));assert(validPolygon(gate));assert(!validPolygon([[0,0],[1,1],[0,1],[1,0]]));assert(!validPolygon([[0,0],[0,0],[0,0],[0,0]]));assert.equal(occupancy([box(0,0,1,1),box(0,0,1,1)],all),1);
let tr=new Tracker(),cl=new Classifier(),r;for(let t=0;t<=4;t+=.5)r=cl.update(tr.update([box(.4,.4,.1,.2)],t),t,z);assert.equal(r.stopped,1);assert.equal(r.gateSeconds,4);assert(r.congestion<35);assert(r.safety<100);
tr=new Tracker();cl=new Classifier();for(let t=0;t<=3;t+=.5)r=cl.update(tr.update([box(.4,.4,.1,.2),box(.5,.4,.05,.2,'person')],t),t,z);assert.equal(r.riskClass,'위험');assert(r.safety<=35);
tr=new Tracker();cl=new Classifier();for(let t=0;t<=3;t+=.5)r=cl.update(tr.update([box(.8,.4,.1,.2)],t),t,z);assert.equal(r.riskClass,'위험');assert.equal(r.intrusionSeconds,3);
r=cl.update([],3.5,z);assert.equal(r.safety,null);assert.equal(r.congestion,null);assert.equal(r.gateSeconds,0);r=cl.update([box(.1,.1,.1,.1)],4,z,5);assert.equal(r.safety,null);
tr=new Tracker();cl=new Classifier();for(let t=0;t<=3;t+=.5)r=cl.update(tr.update([box(.05+t*.04,.05,.1,.1)],t),t,{road:all,gate:null,walk:null});assert.equal(r.safety,null);assert.equal(r.stopped,0);assert.equal(r.congestionClass,'원활');
console.log('PASS: polygon validation, bounded union occupancy, tracking stop, shared entry hazard, walkway intrusion, missing/dark abstention, missing zones, moving flow.');

