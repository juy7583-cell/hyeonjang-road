import assert from 'node:assert/strict';import {Tracker,Classifier} from './dist/engine.mjs';import {AutoTraffic,applyAutoResult} from './dist/auto-traffic.mjs';
const all=[[0,0],[1,0],[1,1],[0,1]],car=(x,y,c='car')=>({bbox:[x,y,.06,.09],class:c,score:.9});
let tr=new Tracker(),at=new AutoTraffic(),cl=new Classifier(),r;
for(let t=0;t<=4;t+=.25){const ds=tr.update([car(.2,.3),car(.2,.4),car(.28,.35),car(.65+t*.02,.2)],t);r=applyAutoResult(cl.update(ds,t,{road:all}),at.update(ds,t));}
assert(r.autoQueueCount>=3);assert(r.congestion>=75);assert.equal(r.cumulativeTracks,4);assert.equal(r.confirmedVehicles,4);assert(r.meanStopSeconds>=3);assert.equal(r.safetyMode,'자동 관측');
tr=new Tracker();at=new AutoTraffic();cl=new Classifier();for(let t=0;t<=3;t+=.25){const ds=tr.update([car(.1+t*.07,.3),car(.4+t*.06,.5)],t),m=at.update(ds,t);r=applyAutoResult(cl.update(ds,t,{road:all}),m);}assert(r.congestion<35);assert.equal(r.autoQueueCount,0);assert.equal(r.cumulativeTracks,2);
const m=at.update([],4,5);assert.equal(m.autoReady,false);assert.equal(m.autoRisk,null);
// A confirmed truck turns near two stationary cars; this is a sign, not a lane violation.
at=new AutoTraffic();let found=false;for(let t=0;t<=4;t+=.25){const p=t<2?[.3+t*.025,.3]:[.35,.3+(t-2)*.025];const ds=[{...car(...p,'truck'),id:1,stationary:false},{...car(.36,.39),id:2,stationary:true},{...car(.42,.4),id:3,stationary:true}];const m=at.update(ds,t);if(m.forecast==='혼잡 증가 징후')found=true;}assert(found);
console.log('PASS: no-zone queue, moving control, confirmed/unique counts, time metrics, darkness abstention, turning-with-queue signs');
