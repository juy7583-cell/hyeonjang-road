export const VEHICLE_TYPES={mixer:'레미콘 형태',dump:'덤프트럭 형태',crane:'이동식 크레인 형태',excavator:'굴착기 형태',pump:'콘크리트 펌프카 형태',other:'일반 차량 형태',unknown:'세부 차종 판단 보류'};
export function predictKNN(vector,bank){
 const ranked=bank.examples.map(e=>({id:e.id,label:e.label,similarity:e.vector.reduce((s,x,i)=>s+x*vector[i],0)})).sort((a,b)=>b.similarity-a.similarity).slice(0,bank.k);
 const votes={};for(const n of ranked)votes[n.label]=(votes[n.label]||0)+1;
 const winner=Object.entries(votes).sort((a,b)=>b[1]-a[1])[0];
 const share=winner?winner[1]/ranked.length:0,similarity=ranked[0]?.similarity??0;
 return {label:share>=2/3&&similarity>=.55?winner[0]:'unknown',vote:share,similarity,neighbors:ranked};
}
export function buildFeatureModel(tf,base){return tf.model({inputs:base.inputs,outputs:tf.layers.globalAveragePooling2d({}).apply(base.getLayer('conv_pw_13_relu').output)});}
export function imageFeatures(tf,model,tensor){return tf.tidy(()=>{const x=tf.image.resizeBilinear(tensor.toFloat(),[224,224],false).div(127.5).sub(1).expandDims(0);const v=model.predict(x).reshape([-1]);return Array.from(v.div(v.norm().add(1e-8)).dataSync());});}
export async function loadVehicleClassifier(tf){
 const [base,res]=await Promise.all([tf.loadLayersModel(new URL('vehicle-model/model.json',import.meta.url).href),fetch(new URL('vehicle-model/knn.json',import.meta.url))]);
 if(!res.ok)throw Error('차종 학습자료를 불러오지 못했습니다');
 const bank=await res.json(),model=buildFeatureModel(tf,base);
 return {bank,classify(canvas){const t=tf.browser.fromPixels(canvas);try{return predictKNN(imageFeatures(tf,model,t),bank)}finally{t.dispose()}}};
}
