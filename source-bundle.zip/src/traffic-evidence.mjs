import {VEHICLES,foot,inside,trafficMetrics} from './engine.mjs';
const distance=(a,b)=>Math.hypot(...foot(a).map((x,i)=>x-foot(b)[i]));
export function signature(pixels,w,h,b){
 if(!pixels)return null;const out=[];for(let j=0;j<20;j++)for(let i=0;i<20;i++){const x=Math.max(0,Math.min(w-1,Math.floor((b[0]+b[2]*(i+.5)/20)*w))),y=Math.max(0,Math.min(h-1,Math.floor((b[1]+b[3]*(j+.5)/20)*h))),k=(y*w+x)*4;out.push((pixels[k]+pixels[k+1]+pixels[k+2])/3)}return out;
}
export function sameAppearance(a,b){if(!a||!b)return false;const ma=a.reduce((s,x)=>s+x,0)/a.length,mb=b.reduce((s,x)=>s+x,0)/b.length;let aa=0,bb=0,ab=0,mad=0;for(let i=0;i<a.length;i++){const x=a[i]-ma,y=b[i]-mb;aa+=x*x;bb+=y*y;ab+=x*y;mad+=Math.abs(a[i]-b[i])}return Math.sqrt(aa/a.length)>8&&Math.sqrt(bb/b.length)>8&&ab/Math.sqrt(aa*bb)>.75&&mad/a.length<28;}
// Retain only previously observed stationary vehicles with current visual support.
// Never turn the absence of detections into evidence of clearance.
export class TrafficEvidence{
 constructor(){this.memory=[];this.last=null;this.candidateSince=null;this.stableScore=null;this.lastEvidence=null;this.clearSince=null;this.queueAnchors=[];}
 update(ds,t,{pixels=null,width=0,height=0,light=120,road,queue=null}={}){
  const current=ds.filter(d=>VEHICLES.has(d.class)&&d.confirmed&&inside(foot(d),road));
  const retained=[],next=[];
  for(const m of this.memory){
   const match=current.find(d=>distance(d,m)<Math.max(.025,m.bbox[2]*.6));
   if(match?.stationary)continue;
   if(t-m.seen>8||light<18)continue;
   // Small alignment search tolerates detector-box jitter/compression. The
   // original template stays fixed so matching cannot drift indefinitely.
   let visible=false;for(const dx of [0,-.12,.12,-.24,.24]){for(const dy of [0,-.12,.12,-.24,.24]){const b=[m.bbox[0]+dx*m.bbox[2],m.bbox[1]+dy*m.bbox[3],m.bbox[2],m.bbox[3]];if(sameAppearance(m.patch,signature(pixels,width,height,b))){visible=true;break}}if(visible)break}
   if(visible){
    const d={...m,stationary:true,retained:true};retained.push(d);next.push(m);
   }
  }
  const supported=current.filter(d=>!retained.some(m=>distance(d,m)<Math.max(.025,m.bbox[2]*.6)));
  for(const d of supported.filter(d=>d.stationary))next.push({...d,seen:t,patch:signature(pixels,width,height,d.bbox)});
  this.memory=next;const all=[...supported,...retained];
  const ready=light>=18&&t>=2&&all.length>0;
  const global=trafficMetrics(all,road,ready),local=trafficMetrics(all,queue,ready);
  let cluster=[],raw=global.score,scope='전체 관측';
  if(local.score!==null&&(raw===null||local.score>raw)){raw=local.score;scope='선택 구역';}
  for(const d of all.filter(d=>d.stationary)){
   const near=all.filter(e=>distance(d,e)<Math.max(.05,Math.max(d.bbox[2],e.bbox[2])*2.5)&&Math.max(d.bbox[2],e.bbox[2])/Math.max(.001,Math.min(d.bbox[2],e.bbox[2]))<3);
   const stop=near.filter(e=>e.stationary);if(stop.length<3)continue;
   const s=Math.round(70*stop.length/near.length+30*Math.min(stop.length/6,1));
   if(raw===null||s>raw){raw=s;cluster=stop;scope='국소 정지 집단';}
  }
  const stops=all.filter(d=>d.stationary).length;
  if(raw!==null&&stops<3)raw=Math.min(raw,60);
  const dt=this.last===null?0:Math.max(0,Math.min(.5,t-this.last));this.last=t;
  let state='관측 중',score=null;
  if(!ready){state='판단 보류';this.candidateSince=null;this.clearSince=null;}
  else {
   if(raw>=65){this.candidateSince??=t;this.clearSince=null;if(t-this.candidateSince>=.75){this.stableScore=raw;this.lastEvidence=t;this.queueAnchors=all.filter(d=>d.stationary);}score=this.stableScore??Math.min(raw,60);state=this.stableScore!==null?'정체 징후 지속':'정지 집단 확인 중';}
   else{this.candidateSince=null;
    // Clearance requires observed moving vehicles, not a drop in detector count.
    const moving=supported.filter(d=>!d.stationary&&d.relativeSpeed>.25).length;
    if(this.stableScore!==null){
     if(moving>=3&&stops===0)this.clearSince??=t;else this.clearSince=null;
     const remaining=all.filter(d=>d.stationary&&this.queueAnchors.some(a=>distance(d,a)<Math.max(.025,a.bbox[2]*.6))).length;
     if(remaining>=2){score=this.stableScore;this.lastEvidence=t;state='같은 대기열 잔존 · 직전 점수 추정 유지';}
     else if(this.clearSince!==null&&t-this.clearSince>=1.5){this.stableScore=null;score=raw;state='이동 재개 관측';}
     else if(this.lastEvidence!==null&&t-this.lastEvidence<=1){score=this.stableScore;state='일시 누락 · 직전 관측 유지';}
     else {score=null;state='정체 해소 미확인 · 판단 보류';}
    }else score=raw;
   }
  }
  if(retained.length&&score!==null)state+=' · 영상 대조 보완';
  return {evidenceVehicles:all.length,detectedVehicles:current.length,retainedVehicles:retained.length,evidenceStopped:stops,evidenceQueue:cluster.length,evidenceRaw:ready?raw:null,evidenceScore:score,evidenceState:state,evidenceScope:scope,evidenceGlobal:global,evidenceLocal:local};
 }
}
export function applyEvidence(r,e){Object.assign(r,e);r.congestion=e.evidenceScore;r.congestionClass=r.congestion===null?'판단 보류':r.congestion<35?'원활':r.congestion<65?'서행':'혼잡';r.congestionScope=e.evidenceScope;r.globalTraffic=e.evidenceGlobal;r.localTraffic=e.evidenceLocal;r.stopped=e.evidenceStopped;r.occupancy=e.evidenceGlobal.fill;r.stopRatio=e.evidenceGlobal.ratio;r.autoQueueCount=e.evidenceQueue;
 const detected=r.risk!==null&&r.risk>0;r.safety=null;r.riskClass=detected?'위험 징후 관측':r.autoReady?'특정 징후 미검출':'판단 보류';r.safetyObservation=r.riskClass;r.reasons=r.reasons.filter(x=>!x.startsWith('도로 내'));if(e.evidenceStopped)r.reasons.push(`관측·보완 정지 ${e.evidenceStopped}대`);r.reasons.push(e.evidenceState);if(r.congestion>=65&&r.forecast!=='혼잡 증가 징후')r.forecast='정체 징후 지속';return r;}
