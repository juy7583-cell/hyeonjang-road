import {VEHICLES,foot,trafficMetrics} from './engine.mjs';
const median=v=>{const a=[...v].sort((a,b)=>a-b);return a.length?a[Math.floor(a.length/2)]:0};
const angle=(a,b)=>Math.abs(Math.atan2(Math.sin(a-b),Math.cos(a-b)))*180/Math.PI;
export class AutoTraffic{
 constructor(){this.history=new Map();this.ids=new Set();this.last=null;this.start=null;this.waitVehicleSeconds=0;this.hazardHold=0;}
 update(ds,t,light=120){
  const dt=this.last===null?0:Math.max(0,Math.min(.5,t-this.last));this.last=t;const valid=light>=18&&ds.some(d=>VEHICLES.has(d.class));if(!valid)this.start=null;else this.start??=t;
  for(const d of ds){let h=this.history.get(d.id);if(!h){h={points:[],hits:0,first:t,stopSince:null};this.history.set(d.id,h)}h.hits++;h.last=t;const p=foot(d);h.points.push({t,p,w:d.bbox[2]});h.points=h.points.filter(x=>t-x.t<=4);d.confirmed=h.hits>=3&&t-h.first>=.5;if(d.confirmed&&VEHICLES.has(d.class))this.ids.add(d.id);
   const recent=h.points.filter(x=>t-x.t<=.85),old=recent[0],span=t-old.t,dx=p[0]-old.p[0],dy=p[1]-old.p[1];d.relativeSpeed=span>=.5?Math.hypot(dx,dy)/Math.max(.025,d.bbox[2])/span:null;
   const before=h.points.filter(x=>t-x.t>=.8&&t-x.t<=1.8),b0=before[0],b1=before.at(-1);let previousSpeed=null,previousHeading=null;
   if(b0&&b1&&b1.t-b0.t>=.5){const bx=b1.p[0]-b0.p[0],by=b1.p[1]-b0.p[1];previousSpeed=Math.hypot(bx,by)/Math.max(.025,d.bbox[2])/(b1.t-b0.t);previousHeading=Math.atan2(by,bx);}
   d.turning=d.relativeSpeed>.15&&previousSpeed>.15&&angle(Math.atan2(dy,dx),previousHeading)>35;
   d.slowing=previousSpeed>.3&&d.relativeSpeed!==null&&d.relativeSpeed<previousSpeed*.55;
   d.speeding=previousSpeed>.2&&d.relativeSpeed>previousSpeed*1.8&&d.relativeSpeed>.8;
   const stable=h.points.filter(x=>t-x.t<=2.1);if(stable.length>=5&&t-stable[0].t>=1.75){const first=stable.slice(0,3),last=stable.slice(-3),mx=median(last.map(x=>x.p[0]))-median(first.map(x=>x.p[0])),my=median(last.map(x=>x.p[1]))-median(first.map(x=>x.p[1]));const spread=Math.max(...stable.map(x=>Math.hypot(x.p[0]-p[0],x.p[1]-p[1])));d.stationary=Math.hypot(mx,my)<=Math.max(.005,d.bbox[2]*.2)&&spread<=Math.max(.015,d.bbox[2]*.6);}
   if(d.stationary)h.stopSince??=Math.max(h.first,t-2);else h.stopSince=null;d.stopSeconds=h.stopSince===null?0:t-h.stopSince;
  }
  for(const [id,h]of this.history)if(t-h.last>5)this.history.delete(id);
  const cars=ds.filter(d=>VEHICLES.has(d.class)&&d.confirmed),people=ds.filter(d=>d.class==='person'&&d.confirmed),stopped=cars.filter(d=>d.stationary),ready=valid&&cars.length>0&&this.start!==null&&t-this.start>=2;
  const near=(a,b)=>{const p=foot(a),q=foot(b);return Math.hypot(p[0]-q[0],p[1]-q[1])<=Math.max(.055,Math.max(a.bbox[2],b.bbox[2])*3)&&Math.max(a.bbox[2],b.bbox[2])/Math.max(.001,Math.min(a.bbox[2],b.bbox[2]))<4};
  let cluster=[],score=null;for(const s of stopped){const neighbors=cars.filter(d=>near(s,d)),n=neighbors.filter(d=>d.stationary).length;if(n<2)continue;let v=Math.round(70*n/neighbors.length+30*Math.min(1,neighbors.length/6));if(n>=3&&n/neighbors.length>=.6)v=Math.max(75,v);if(score===null||v>score){score=v;cluster=neighbors;}}
  const large=cars.filter(d=>d.class==='truck'||d.class==='bus'),turns=large.filter(d=>d.turning),slows=large.filter(d=>d.slowing),speeds=large.filter(d=>d.speeding),affected=large.filter(d=>(d.turning||d.slowing)&&stopped.filter(s=>s.id!==d.id&&near(s,d)).length>=2);
  const closePeople=people.some(p=>cars.some(c=>{const a=foot(p),b=foot(c);return Math.hypot(a[0]-b[0],a[1]-b[1])<Math.max(.025,c.bbox[2]*.75)&&!c.stationary}));
  const hazard=closePeople||affected.length>0||speeds.some(d=>cars.some(c=>c.id!==d.id&&near(c,d)));this.hazardHold=hazard?this.hazardHold+dt:0;
  let risk=closePeople?65:0;if(affected.length)risk+=35;if(speeds.some(d=>cars.some(c=>c.id!==d.id&&near(c,d))))risk+=25;risk=this.hazardHold>=.5?Math.min(100,risk):0;
  if(ready)this.waitVehicleSeconds+=stopped.length*dt;
  const reasons=[];if(ready&&affected.length)reasons.push('대형 차량 방향·속도 변화와 주변 정지 동시 관측');if(ready&&closePeople&&this.hazardHold>=.5)reasons.push('화면상 보행자·이동 차량 근접');
  return {autoReady:ready,autoCongestion:ready?score:null,autoQueueCount:ready?cluster.filter(d=>d.stationary).length:0,confirmedVehicles:cars.length,cumulativeTracks:this.ids.size,meanStopSeconds:stopped.length?stopped.reduce((s,d)=>s+d.stopSeconds,0)/stopped.length:0,waitVehicleSeconds:this.waitVehicleSeconds,turningLarge:turns.length,slowingLarge:slows.length,speedingLarge:speeds.length,forecast:!ready?'판단 보류':affected.length?'혼잡 증가 징후':turns.length||slows.length?'대형 차량 변화 관찰':cluster.length?'대기열 지속 관찰':'뚜렷한 증가 징후 없음',autoRisk:ready?risk:null,autoReasons:reasons};
 }
}
export function applyAutoResult(r,m,{manualRoad=false}={}){
 Object.assign(r,m);if(!manualRoad&&m.autoCongestion!==null&&(r.congestion===null||m.autoCongestion>r.congestion)){r.congestion=m.autoCongestion;r.congestionScope='자동 대기열';}
 if(r.safety===null&&m.autoReady){r.risk=m.autoRisk;r.safety=100-m.autoRisk;r.riskClass=m.autoRisk<30?'낮음':m.autoRisk<65?'주의':'위험';r.quality='자동 관측 · 실제 안전 보증 아님';r.safetyMode='자동 관측';}
 else r.safetyMode='지정 구역';
 r.congestionClass=r.congestion===null?'판단 보류':r.congestion<35?'원활':r.congestion<65?'서행':'혼잡';r.reasons.push(...m.autoReasons);return r;
}
